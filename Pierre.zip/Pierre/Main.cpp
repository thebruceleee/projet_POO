// main.cpp
#include "Programme.h"

int main() {
    Programme jeuDeLaVie;
    // Programme (initialisation)
    jeuDeLaVie.demarrer();
    // Utilitaire (test unitaire) - peut �tre ajout� ici, mais pas dans le main

    return 0;
}