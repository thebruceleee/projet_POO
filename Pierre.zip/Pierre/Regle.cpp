#include "Regle.hpp"

using namespace std;

Regles::Regles()
    : m_modeGraphique(false), m_maxIterations(0)
{
    // Les m_lois sont initialis�es automatiquement avec les r�gles de Conway
    // gr�ce au constructeur par d�faut de la struct LoisBiologiques.
}

void Regles::setLois(const LoisBiologiques& nouvellesLois) {
    // On pourrait ajouter ici des assertions pour v�rifier la coh�rence
    // Exemple : if (nouvellesLois.isolement > nouvellesLois.surpop) ...
    m_lois = nouvellesLois;
}

const LoisBiologiques& Regles::getLois() const {
    return m_lois;
}

void Regles::setModeGraphique(bool actif) {
    m_modeGraphique = actif;
}

bool Regles::isModeGraphique() const {
    return m_modeGraphique;
}

void Regles::setMaxIterations(unsigned int max) {
    m_maxIterations = max;
}

bool Regles::aUneLimiteDeTemps() const {
    // Plus �l�gant que de g�rer un bool�en s�par�
    return m_maxIterations > 0;
}

unsigned int Regles::getMaxIterations() const {
    return m_maxIterations;
}