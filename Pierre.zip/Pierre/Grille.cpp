#include "Grille.hpp"

// Constructeur : 
// On utilise la liste d'initialisation pour configurer les dimensions et 
// allouer le vecteur en une seule fois. C'est plus rapide que de faire des push_back.
Grille::Grille(int largeur, int hauteur)
    : m_largeur(largeur), m_hauteur(hauteur), m_grid(largeur* hauteur)
{
    // Une fois le vecteur allou�, on configure les coordonn�es internes de chaque cellule
    initialiserGrille();
}

// M�thode priv�e pour configurer les cellules apr�s allocation
void Grille::initialiserGrille() {
    for (int y = 0; y < m_hauteur; ++y) {
        for (int x = 0; x < m_largeur; ++x) {
            // On r�cup�re la cellule et on lui dit "tu es en (x,y)"
            // Note : accessCell g�re la conversion 2D -> 1D
            accessCell(x, y).setCoords(x, y);
        }
    }
}

// Accesseur Modifiable
// Conversion de coordonn�es (x, y) vers l'index lin�aire i = y * largeur + x
Cell& Grille::accessCell(int x, int y) {
    return m_grid[y * m_largeur + x];
}

// Accesseur Constant (Lecture seule)
const Cell& Grille::accessCell(int x, int y) const {
    return m_grid[y * m_largeur + x];
}

// Calcul des voisins optimis� (Math�matiques vs Conditionnelles)
// Cette m�thode remplace "iteration(Cell* cell)"
int Grille::compterVoisinsVivants(int x, int y) const {
    int voisinsVivants = 0;

    // Parcours des 8 voisins relatifs (-1, 0, +1)
    for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {

            // On saute la cellule centrale (soi-m�me)
            if (dx == 0 && dy == 0) continue;

            // Gestion du Tore (Monde circulaire) via l'op�rateur Modulo (%).
            // Formule : (coord + delta + dimension) % dimension
            // Cela g�re automatiquement les d�passements positifs et n�gatifs
            // sans avoir besoin de 4 blocs if/else.
            int voisinX = (x + dx + m_largeur) % m_largeur;
            int voisinY = (y + dy + m_hauteur) % m_hauteur;

            // On acc�de directement � la cellule dans le vecteur contigu
            if (accessCell(voisinX, voisinY).estVivante()) {
                voisinsVivants++;
            }
        }
    }

    return voisinsVivants;
}