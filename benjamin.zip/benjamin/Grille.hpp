#ifndef GRILLE_HPP
#define GRILLE_HPP

#include <vector>
#include "Cellule.hpp"

/**
 * @class Grille
 * @brief Repr�sente l'espace de simulation du Jeu de la Vie.
 * * Conception optimis�e :
 * Utilise un std::vector lin�aris� (1D) pour stocker une grille 2D.
 * Cela garantit la contigu�t� m�moire et am�liore les performances du cache CPU
 * par rapport � un tableau de pointeurs ou un double vecteur.
 */
class Grille {
private:
    int m_largeur;
    int m_hauteur;

    // Conteneur unique stockant toutes les cellules.
    // L'acc�s (x, y) est converti en index (y * largeur + x).
    std::vector<Cell> m_grid;

    // M�thode interne pour initialiser ou r�initialiser la grille
    void initialiserGrille();

public:
    // Constructeur : Alloue dynamiquement la m�moire via le vecteur
    Grille(int largeur, int hauteur);

    // Destructeur : Optionnel en C++ moderne car std::vector g�re sa propre m�moire.
    // On le d�finit par d�faut pour la clart�.
    ~Grille() = default;

    // --- Accesseurs (Getters) ---

    int getLargeur() const { return m_largeur; }
    int getHauteur() const { return m_hauteur; }

    // Acc�s en lecture/�criture (retourne une r�f�rence)
    Cell& accessCell(int x, int y);

    // Acc�s en lecture seule (const correctness)
    const Cell& accessCell(int x, int y) const;

    // --- Logique m�tier ---

    // Calcule le nombre de voisins vivants pour une position donn�e.
    // Utilise une logique toro�dale (les bords sont connect�s).
    int compterVoisinsVivants(int x, int y) const;

    // Accesseur direct au tableau brut (utile pour l'affichage rapide ou le debug)
    const std::vector<Cell>& getData() const { return m_grid; }
};

#endif // GRILLE_HPP