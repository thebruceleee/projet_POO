#ifndef GAME_HPP
#define GAME_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>
#include <vector>

// Inclusion des modules refactoris�s
#include "Grille.hpp"
#include "Regle.hpp"

/**
 * @class Game
 * @brief Contr�leur principal de l'application (Pattern MVC).
 * * Cette classe orchestre :
 * 1. Le Mod�le : La Grille (donn�es) et les R�gles (logique).
 * 2. La Vue : Le rendu SFML (m�thode render).
 * 3. Les Entr�es : Gestion des modes de jeu (Glider, Obstacle, etc.).
 */
class Game {
public:
    // Constructeur : Pr�pare la grille et charge les assets (RAII)
    Game(int largeur, int hauteur);

    // Destructeur par d�faut (les objets SFML et vector se nettoient seuls)
    ~Game();

    // --- Boucle de Jeu ---

    // Met � jour la simulation d'une �tape (Calcul physique)
    // Prend les r�gles en lecture seule (const ref) pour �viter les effets de bord.
    void update(const Regles& regles);

    // Affiche toute la sc�ne (Grille + UI + Fant�mes)
    void render(sf::RenderWindow& window, int cellSize, int modeJeu);

    // --- Gestion de fichiers ---

    // Sauvegarde l'�tat actuel dans un fichier texte (anciennement 'display')
    void saveToText(int generation, const std::string& filename) const;

    // --- Contr�les & Accesseurs ---

    void startMusic() { m_music.play(); }
    void stopMusic() { m_music.stop(); }

    // Acc�s direct � la grille pour les interactions souris dans le Main
    Grille& getGrille() { return m_grille; }
    const Grille& getGrille() const { return m_grille; }

private:
    // --- Membres (Pr�fixe m_ pour 'member') ---

    Grille m_grille;

    // Ressources SFML
    sf::Music m_music;
    sf::Font m_fontRoboto;
    sf::Font m_fontScript;

    // --- M�thodes Internes (Helpers) ---
    // Ces fonctions sont cach�es de l'utilisateur de la classe

    void initResources();
    void drawGrid(sf::RenderWindow& window, int cellSize);
    void drawUI(sf::RenderWindow& window, int cellSize, int mode);
    void drawPreview(sf::RenderWindow& window, int cellSize, int gx, int gy, int mode);
};

#endif // GAME_HPP