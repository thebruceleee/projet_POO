#ifndef REGLE_HPP
#define REGLE_HPP

#include <iostream>

// Structure simple pour regrouper les lois biologiques.
// C'est une bonne pratique ("Data Oriented") de grouper les donn�es li�es.
struct LoisBiologiques {
    unsigned int isolement;   // Meurt si < � ce nombre (ex: 2)
    unsigned int surpop;      // Meurt si > � ce nombre (ex: 3)
    unsigned int naissance;   // Nait si == � ce nombre (ex: 3)

    // Constructeur par d�faut : R�gles standards du "Game of Life" (Conway)
    LoisBiologiques(unsigned int iso = 2, unsigned int surp = 3, unsigned int naiss = 3)
        : isolement(iso), surpop(surp), naissance(naiss) {
    }
};

/**
 * @class Regles
 * @brief Gestionnaire de configuration de la simulation.
 * * Cette classe centralise le param�trage (seuils de vie/mort)
 * ainsi que les limites de la simulation (mode d'affichage, it�rations max).
 */
class Regles {
private:
    // Configuration du moteur de jeu
    LoisBiologiques m_lois;

    // Configuration de l'ex�cution
    bool m_modeGraphique;
    unsigned int m_maxIterations; // 0 signifie "Infini"

public:
    // Constructeur avec valeurs par d�faut
    Regles();
    ~Regles() = default;

    // --- Gestion des Lois Biologiques ---

    // D�finit de nouvelles r�gles biologiques via la structure d�di�e
    void setLois(const LoisBiologiques& nouvellesLois);

    // R�cup�re les lois actuelles (lecture seule)
    const LoisBiologiques& getLois() const;

    // --- Gestion de la Simulation ---

    void setModeGraphique(bool actif);
    bool isModeGraphique() const;

    // D�finit la limite d'it�rations. 0 = Simulation infinie.
    void setMaxIterations(unsigned int max);

    // V�rifie si la simulation a une fin programm�e
    bool aUneLimiteDeTemps() const;

    unsigned int getMaxIterations() const;
};

#endif // REGLE_HPP