#ifndef CELL_HPP
#define CELL_HPP

// On remplace les multiples classes par une �num�ration typ�e (C++11).
// Cela tient sur un seul octet en m�moire (char) au lieu d'un pointeur (8 octets).
enum class EtatCellule : char {
    MORTE,
    VIVANTE,
    // Les obstacles sont des �tats statiques qui ne changent pas
    OBSTACLE_VIVANT,
    OBSTACLE_MORT
};

/**
 * @class Cell
 * @brief Brique fondamentale de la simulation.
 * * Optimisation : Cette classe est con�ue comme un "Value Type".
 * Elle ne g�re pas de m�moire dynamique (pas de new/delete),
 * ce qui la rend extr�mement rapide � copier et � stocker dans un std::vector.
 */
class Cell {
private:
    int m_x;
    int m_y;
    EtatCellule m_etat;

public:
    // Constructeur : Initialisation directe, pas d'allocation dynamique.
    Cell(int x = 0, int y = 0, EtatCellule etatInit = EtatCellule::MORTE);

    // Le destructeur est implicite et trivial (gain de performance).
    ~Cell() = default;

    // --- Accesseurs ---
    int getX() const { return m_x; }
    int getY() const { return m_y; }

    // --- Logique M�tier ---

    // V�rifie si la cellule contribue � la population (Vivant ou Obstacle Vivant)
    bool estVivante() const;

    // V�rifie si la cellule est fig�e (Obstacle)
    bool estObstacle() const;

    // --- Mutateurs (Actions) ---
    // Ces m�thodes remplacent les "new/delete" de l'ancienne version

    void rendreVivante();
    void rendreMorte();

    // Gestion sp�cifique des obstacles
    void setObstacle(bool actif, bool vivant);
};

#endif // CELL_HPP